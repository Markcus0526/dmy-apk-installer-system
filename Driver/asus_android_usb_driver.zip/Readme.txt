ASUS Android USB drivers for Windows

VID: 0B05

PID for single ADB interface: 4DAE
PID for fastboot: 4DAF

TF101, TF101G, TF101-WiMAX:
PID for MTP: 4E0F
PID for MTP + ADB: 4E1F
PID for RNDIS: 4E2F
PID for RNDIS + ADB: 4E3F
PID for PTP: 4E4F
PID for PTP + ADB: 4E5F

SL101:
PID for MTP: 4E00
PID for MTP + ADB: 4E01
PID for RNDIS: 4E02
PID for RNDIS + ADB: 4E03
PID for PTP: 4E04
PID for PTP + ADB:  4E05

TF300T, TF300TG, TF300TL:
PID for MTP: 4C80
PID for MTP + ADB: 4C81
PID for RNDIS: 4C82
PID for RNDIS + ADB: 4C83
PID for PTP: 4C84
PID for PTP + ADB: 4C85

TF201:
PID for MTP: 4D00
PID for MTP + ADB: 4D01
PID for RNDIS: 4D02
PID for RNDIS + ADB: 4D03
PID for PTP: 4D04
PID for PTP + ADB: 4D05

TF700T:
PID for MTP: 4C90
PID for MTP + ADB: 4C91
PID for RNDIS: 4C92
PID for RNDIS + ADB: 4C93
PID for PTP: 4C94
PID for PTP + ADB: 4C95

*:
PID for MTP: 4CA0
PID for MTP + ADB: 4CA1
PID for RNDIS: 4CA2
PID for RNDIS + ADB: 4CA3
PID for PTP: 4CA4
PID for PTP + ADB: 4CA5

DaiHuKu:
PID for MTP: 4DDF
PID for MTP + ADB: 4DEF
PID for RNDIS: 4DDD
PID for RNDIS + ADB: 4DDE

ME171:
PID for Mass Storage + Serial + DIAG + RmNet: 4F0F
PID for Mass Storage + Serial + DIAG + RmNet + ADB: 4F1F
PID for Mass Storage: 4F2F
PID for Mass Storage + ADB: 4F3F
PID for Ethernet: 4F4F
PID for Ethernet + ADB: 4F5F
PID for MTP: 4F6F
PID for MTP + ADB: 4F7F

A66:
PID for MTP: 5200
PID for MTP + ADB: 5201
PID for Mass Storage: 5202
PID for Mass Storage + ADB: 5203
PID for Ethernet: 5204
PID for Ethernet + ADB: 5205
PID for PTP: 5206
PID for PTP + ADB: 5207

TF700K:
PID for MTP: 504F
PID for MTP + ADB: 505F
PID for RNDIS: 502F
PID for RNDIS + ADB: 503F
PID for PTP: 506F
PID for PTP + ADB: 507F

Release note

================================================================================
2012/02/09

1. Add support of MTP, Mass Storage, Ethernet, ADB, and PTP for A66.
2. Add PID 4DAE for single ADB interface for all projects for x86 cases.
3. Add TF101G and TF101-WiMAX as well as make them same as TF101.
4. Change TF300T to TF700T
5. Change TF201X to TF300T, add TF300TG and TF300TL, and make them same as TF300T.
6. Change ME271 to *.
7. Add support of MTP, Ethernet, ADB, and PTP support for TF700K.
================================================================================
2011/12/01

1. Add PTP + ADB support for TF201.
2. Add PID 4DAE for single ADB interface for all projects.
3. Add PTP + ADB support for TF101.
4. Add PTP + ADB support for SL101.
5. Add MTP, PTP, RNDIS, and ADB support for TF201X.
6. Add MTP, PTP, RNDIS, and ADB support for TF300T.
7. Add MTP, PTP, RNDIS, and ADB support for ME271.
8. Add MTP, Ethernet, and ADB support for ME171.
9. This package has been certified.
================================================================================
2011/09/29

1. Add the category file for the ADB driver. Now the ADB driver is certified.
2. Add the category file for the MTP driver. Now the MTP driver is certified.
3. Add the category file for the RNDIS driver. Now the RNDIS driver is certified.
================================================================================
2011/09/25

1. Change A60 to TF201 and add the support of MTP for TF201.
2. Add the support of MTP, ADB, and RNDIS support for DaiHuKu.
3. Modify "DriverVer" to "09/25/2011,4.0.0000.1" for ADB.
4. Modify "DriverVer" to "09/25/2011,1.0.0.1" for MTP.
5. Modify "DriverVer" to "09/25/2011,1.0.0.1" for RNDIS.
================================================================================
2011/03/21

Add the category file for the tethering driver. Now the tethering driver is
certified.
================================================================================
2011/03/14

Add the category file for the MTP driver. Now the MTP driver is certified.
================================================================================
2011/03/10

Add the category files for the ADB driver. Now the ADB driver is certified.
================================================================================
2011/03/09-2

Fix the problem for the undefined token "RndisDevice" for the
Ethernet/RNDIS drivers.
================================================================================
2011/03/09-1

Fix the problem that the Ethernet/RNDIS drivers can not work with x64 OS.
================================================================================
2011/03/09

Modify the driver version of MTP to 1.0.0.0.
================================================================================
2011/03/02

Fix the bug that the MTP driver can not be installed in x64.
================================================================================
2011/02/27

1. Add the driver for Ethernet/RNDIS.
2. Correct the provider name to ASUSTeK COMPUTER INC for the MTP driver.
================================================================================
2011/02/26

Add the driver for MTP.
================================================================================
2011/02/24

Correct the provider name to ASUSTeK COMPUTER INC. for the ADB driver.
================================================================================
2011/02/23-1

Correct the ADB interface number for Ethernet.
================================================================================
2011/02/23

1. Rename EP101 to TF101.
2. Add ADB support for SL101.
3. Change MSC for TF101 to MTP.
================================================================================
2011/01/24

1. Support ASUS A60 MSC + ADB.
2. Update the Android USB drivers for Windows to Revesion 4 (December 2010).
3. Remove NVIDIA USB Boot-recovery driver for Mobile devices.
================================================================================
2010/12/14

Add ASUS Android Bootloader Interface for fastboot.
================================================================================
2010/12/09

Add NVIDIA USB Boot-recovery driver for Mobile devices.
================================================================================
2010/10/15

1. Create this to support ASUS EP101 MSC + ADB.
2. The current drivers are not certified.
================================================================================
