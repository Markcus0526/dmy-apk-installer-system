using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace CustomAutoScrollPanel
{
	/// <summary>
	/// Description r�sum�e de Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private CustomAutoScrollPanel.ScrollablePanel panel1;
		private System.Windows.Forms.Panel panel2;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.Button button2;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.CheckBox checkBox1;
		private System.Windows.Forms.CheckBox checkBox2;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.CheckBox checkBox3;
		private System.Windows.Forms.CheckBox checkBox4;
		private System.Windows.Forms.Button button3;
		private System.Windows.Forms.Button button4;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Button button5;
		private System.Windows.Forms.Button button6;
		private System.Windows.Forms.Button button7;
		private System.Windows.Forms.Button button8;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.NumericUpDown numericUpDown1;
		private System.Windows.Forms.NumericUpDown numericUpDown2;
		private System.Windows.Forms.NumericUpDown numericUpDown3;
		private System.Windows.Forms.NumericUpDown numericUpDown4;
		private System.Windows.Forms.Label label9;
		private System.Windows.Forms.Label label10;
		private System.Windows.Forms.NumericUpDown numericUpDown5;
		private System.Windows.Forms.NumericUpDown numericUpDown6;
		private System.Windows.Forms.Label label11;
		/// <summary>
		/// Variable n�cessaire au concepteur.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Requis pour la prise en charge du Concepteur Windows Forms
			//
			InitializeComponent();

			//
			// TODO : ajoutez le code du constructeur apr�s l'appel � InitializeComponent
			//
			//this.panel1.Scr
		}

		/// <summary>
		/// Nettoyage des ressources utilis�es.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Code g�n�r� par le Concepteur Windows Form
		/// <summary>
		/// M�thode requise pour la prise en charge du concepteur - ne modifiez pas
		/// le contenu de cette m�thode avec l'�diteur de code.
		/// </summary>
		private void InitializeComponent()
		{
			this.panel1 = new CustomAutoScrollPanel.ScrollablePanel();
			this.panel2 = new System.Windows.Forms.Panel();
			this.label11 = new System.Windows.Forms.Label();
			this.button1 = new System.Windows.Forms.Button();
			this.button2 = new System.Windows.Forms.Button();
			this.label1 = new System.Windows.Forms.Label();
			this.checkBox1 = new System.Windows.Forms.CheckBox();
			this.checkBox2 = new System.Windows.Forms.CheckBox();
			this.label2 = new System.Windows.Forms.Label();
			this.checkBox3 = new System.Windows.Forms.CheckBox();
			this.checkBox4 = new System.Windows.Forms.CheckBox();
			this.button3 = new System.Windows.Forms.Button();
			this.button4 = new System.Windows.Forms.Button();
			this.label3 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.button5 = new System.Windows.Forms.Button();
			this.button6 = new System.Windows.Forms.Button();
			this.button7 = new System.Windows.Forms.Button();
			this.button8 = new System.Windows.Forms.Button();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.numericUpDown4 = new System.Windows.Forms.NumericUpDown();
			this.numericUpDown3 = new System.Windows.Forms.NumericUpDown();
			this.numericUpDown2 = new System.Windows.Forms.NumericUpDown();
			this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
			this.label8 = new System.Windows.Forms.Label();
			this.label7 = new System.Windows.Forms.Label();
			this.label6 = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this.label9 = new System.Windows.Forms.Label();
			this.label10 = new System.Windows.Forms.Label();
			this.numericUpDown5 = new System.Windows.Forms.NumericUpDown();
			this.numericUpDown6 = new System.Windows.Forms.NumericUpDown();
			this.panel1.SuspendLayout();
			this.panel2.SuspendLayout();
			this.groupBox1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.numericUpDown4)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.numericUpDown3)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.numericUpDown5)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.numericUpDown6)).BeginInit();
			this.SuspendLayout();
			// 
			// panel1
			// 
			this.panel1.AutoScroll = true;
			this.panel1.AutoScrollHorizontalMaximum = 100;
			this.panel1.AutoScrollHorizontalMinimum = 0;
			this.panel1.AutoScrollHPos = 0;
			this.panel1.AutoScrollVerticalMaximum = 100;
			this.panel1.AutoScrollVerticalMinimum = 0;
			this.panel1.AutoScrollVPos = 0;
			this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.panel1.Controls.Add(this.panel2);
			this.panel1.EnableAutoScrollHorizontal = true;
			this.panel1.EnableAutoScrollVertical = true;
			this.panel1.Location = new System.Drawing.Point(24, 80);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(208, 176);
			this.panel1.TabIndex = 0;
			this.panel1.VisibleAutoScrollHorizontal = true;
			this.panel1.VisibleAutoScrollVertical = true;
			this.panel1.ScrollVertical += new System.Windows.Forms.ScrollEventHandler(this.panel1_ScrollVertical);
			this.panel1.ScrollHorizontal += new System.Windows.Forms.ScrollEventHandler(this.panel1_ScrollHorizontal);
			this.panel1.ScrollMouseWheel += new System.Windows.Forms.MouseEventHandler(this.panel1_ScrollMouseWheel);
			// 
			// panel2
			// 
			this.panel2.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
			this.panel2.Controls.Add(this.label11);
			this.panel2.Location = new System.Drawing.Point(24, 16);
			this.panel2.Name = "panel2";
			this.panel2.Size = new System.Drawing.Size(248, 296);
			this.panel2.TabIndex = 0;
			this.panel2.Click += new System.EventHandler(this.panel2_Click);
			// 
			// label11
			// 
			this.label11.Location = new System.Drawing.Point(24, 32);
			this.label11.Name = "label11";
			this.label11.Size = new System.Drawing.Size(136, 56);
			this.label11.TabIndex = 0;
			this.label11.Text = "I\'m a big panel inside a panel with autoscroll=true. clic inside panel to use mou" +
				"sewheel";
			this.label11.Click += new System.EventHandler(this.label11_Click);
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(264, 96);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(112, 24);
			this.button1.TabIndex = 1;
			this.button1.Text = "Large VScroll up";
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// button2
			// 
			this.button2.Location = new System.Drawing.Point(264, 128);
			this.button2.Name = "button2";
			this.button2.Size = new System.Drawing.Size(112, 23);
			this.button2.TabIndex = 2;
			this.button2.Text = "Large VScroll down";
			this.button2.Click += new System.EventHandler(this.button2_Click);
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(16, 272);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(96, 16);
			this.label1.TabIndex = 3;
			this.label1.Text = "Scroll events:";
			// 
			// checkBox1
			// 
			this.checkBox1.Checked = true;
			this.checkBox1.CheckState = System.Windows.Forms.CheckState.Checked;
			this.checkBox1.Location = new System.Drawing.Point(8, 40);
			this.checkBox1.Name = "checkBox1";
			this.checkBox1.Size = new System.Drawing.Size(152, 16);
			this.checkBox1.TabIndex = 4;
			this.checkBox1.Text = "Enable horizontal scroll";
			this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
			// 
			// checkBox2
			// 
			this.checkBox2.Checked = true;
			this.checkBox2.CheckState = System.Windows.Forms.CheckState.Checked;
			this.checkBox2.Location = new System.Drawing.Point(192, 40);
			this.checkBox2.Name = "checkBox2";
			this.checkBox2.Size = new System.Drawing.Size(136, 16);
			this.checkBox2.TabIndex = 5;
			this.checkBox2.Text = "Enable vertical scroll";
			this.checkBox2.CheckedChanged += new System.EventHandler(this.checkBox2_CheckedChanged);
			// 
			// label2
			// 
			this.label2.ForeColor = System.Drawing.Color.OrangeRed;
			this.label2.Location = new System.Drawing.Point(112, 272);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(232, 16);
			this.label2.TabIndex = 6;
			// 
			// checkBox3
			// 
			this.checkBox3.Checked = true;
			this.checkBox3.CheckState = System.Windows.Forms.CheckState.Checked;
			this.checkBox3.Location = new System.Drawing.Point(8, 16);
			this.checkBox3.Name = "checkBox3";
			this.checkBox3.Size = new System.Drawing.Size(160, 16);
			this.checkBox3.TabIndex = 7;
			this.checkBox3.Text = "Visible horizontal scroll";
			this.checkBox3.CheckedChanged += new System.EventHandler(this.checkBox3_CheckedChanged);
			// 
			// checkBox4
			// 
			this.checkBox4.Checked = true;
			this.checkBox4.CheckState = System.Windows.Forms.CheckState.Checked;
			this.checkBox4.Location = new System.Drawing.Point(192, 16);
			this.checkBox4.Name = "checkBox4";
			this.checkBox4.Size = new System.Drawing.Size(136, 16);
			this.checkBox4.TabIndex = 8;
			this.checkBox4.Text = "Visible vertical scroll";
			this.checkBox4.CheckedChanged += new System.EventHandler(this.checkBox4_CheckedChanged);
			// 
			// button3
			// 
			this.button3.Location = new System.Drawing.Point(264, 184);
			this.button3.Name = "button3";
			this.button3.Size = new System.Drawing.Size(112, 24);
			this.button3.TabIndex = 9;
			this.button3.Text = "Large HScroll right";
			this.button3.Click += new System.EventHandler(this.button3_Click);
			// 
			// button4
			// 
			this.button4.Location = new System.Drawing.Point(264, 216);
			this.button4.Name = "button4";
			this.button4.Size = new System.Drawing.Size(112, 23);
			this.button4.TabIndex = 10;
			this.button4.Text = "Large HScroll left";
			this.button4.Click += new System.EventHandler(this.button4_Click);
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(16, 296);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(112, 16);
			this.label3.TabIndex = 11;
			this.label3.Text = "Mousewheel events:";
			// 
			// label4
			// 
			this.label4.ForeColor = System.Drawing.Color.OrangeRed;
			this.label4.Location = new System.Drawing.Point(128, 296);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(216, 16);
			this.label4.TabIndex = 12;
			// 
			// button5
			// 
			this.button5.Location = new System.Drawing.Point(392, 96);
			this.button5.Name = "button5";
			this.button5.Size = new System.Drawing.Size(112, 23);
			this.button5.TabIndex = 13;
			this.button5.Text = "Small VScroll up";
			this.button5.Click += new System.EventHandler(this.button5_Click);
			// 
			// button6
			// 
			this.button6.Location = new System.Drawing.Point(392, 128);
			this.button6.Name = "button6";
			this.button6.Size = new System.Drawing.Size(112, 23);
			this.button6.TabIndex = 14;
			this.button6.Text = "Small VScroll down";
			this.button6.Click += new System.EventHandler(this.button6_Click);
			// 
			// button7
			// 
			this.button7.Location = new System.Drawing.Point(392, 184);
			this.button7.Name = "button7";
			this.button7.Size = new System.Drawing.Size(112, 23);
			this.button7.TabIndex = 15;
			this.button7.Text = "Small HScroll right";
			this.button7.Click += new System.EventHandler(this.button7_Click);
			// 
			// button8
			// 
			this.button8.Location = new System.Drawing.Point(392, 216);
			this.button8.Name = "button8";
			this.button8.Size = new System.Drawing.Size(112, 23);
			this.button8.TabIndex = 16;
			this.button8.Text = "Small HScroll left";
			this.button8.Click += new System.EventHandler(this.button8_Click);
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.Add(this.numericUpDown4);
			this.groupBox1.Controls.Add(this.numericUpDown3);
			this.groupBox1.Controls.Add(this.numericUpDown2);
			this.groupBox1.Controls.Add(this.numericUpDown1);
			this.groupBox1.Controls.Add(this.label8);
			this.groupBox1.Controls.Add(this.label7);
			this.groupBox1.Controls.Add(this.label6);
			this.groupBox1.Controls.Add(this.label5);
			this.groupBox1.Enabled = false;
			this.groupBox1.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.groupBox1.Location = new System.Drawing.Point(336, 8);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(160, 80);
			this.groupBox1.TabIndex = 17;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Range";
			// 
			// numericUpDown4
			// 
			this.numericUpDown4.Location = new System.Drawing.Point(104, 48);
			this.numericUpDown4.Name = "numericUpDown4";
			this.numericUpDown4.Size = new System.Drawing.Size(40, 20);
			this.numericUpDown4.TabIndex = 7;
			this.numericUpDown4.Value = new System.Decimal(new int[] {
																		 100,
																		 0,
																		 0,
																		 0});
			this.numericUpDown4.ValueChanged += new System.EventHandler(this.numericUpDown4_ValueChanged);
			// 
			// numericUpDown3
			// 
			this.numericUpDown3.Location = new System.Drawing.Point(40, 48);
			this.numericUpDown3.Name = "numericUpDown3";
			this.numericUpDown3.Size = new System.Drawing.Size(40, 20);
			this.numericUpDown3.TabIndex = 6;
			this.numericUpDown3.ValueChanged += new System.EventHandler(this.numericUpDown3_ValueChanged);
			// 
			// numericUpDown2
			// 
			this.numericUpDown2.Location = new System.Drawing.Point(104, 24);
			this.numericUpDown2.Name = "numericUpDown2";
			this.numericUpDown2.Size = new System.Drawing.Size(40, 20);
			this.numericUpDown2.TabIndex = 5;
			this.numericUpDown2.Value = new System.Decimal(new int[] {
																		 100,
																		 0,
																		 0,
																		 0});
			this.numericUpDown2.ValueChanged += new System.EventHandler(this.numericUpDown2_ValueChanged);
			// 
			// numericUpDown1
			// 
			this.numericUpDown1.Location = new System.Drawing.Point(40, 24);
			this.numericUpDown1.Name = "numericUpDown1";
			this.numericUpDown1.Size = new System.Drawing.Size(40, 20);
			this.numericUpDown1.TabIndex = 4;
			this.numericUpDown1.ValueChanged += new System.EventHandler(this.numericUpDown1_ValueChanged);
			// 
			// label8
			// 
			this.label8.Location = new System.Drawing.Point(104, 8);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(32, 16);
			this.label8.TabIndex = 3;
			this.label8.Text = "Max";
			// 
			// label7
			// 
			this.label7.Location = new System.Drawing.Point(48, 8);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(32, 16);
			this.label7.TabIndex = 2;
			this.label7.Text = "Min";
			// 
			// label6
			// 
			this.label6.Location = new System.Drawing.Point(16, 48);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(16, 16);
			this.label6.TabIndex = 1;
			this.label6.Text = "V";
			// 
			// label5
			// 
			this.label5.Location = new System.Drawing.Point(16, 24);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(16, 16);
			this.label5.TabIndex = 0;
			this.label5.Text = "H";
			// 
			// label9
			// 
			this.label9.Location = new System.Drawing.Point(392, 272);
			this.label9.Name = "label9";
			this.label9.Size = new System.Drawing.Size(40, 16);
			this.label9.TabIndex = 18;
			this.label9.Text = "H Pos";
			// 
			// label10
			// 
			this.label10.Location = new System.Drawing.Point(392, 296);
			this.label10.Name = "label10";
			this.label10.Size = new System.Drawing.Size(40, 16);
			this.label10.TabIndex = 19;
			this.label10.Text = "V Pos";
			// 
			// numericUpDown5
			// 
			this.numericUpDown5.Location = new System.Drawing.Point(440, 272);
			this.numericUpDown5.Maximum = new System.Decimal(new int[] {
																		   10000,
																		   0,
																		   0,
																		   0});
			this.numericUpDown5.Name = "numericUpDown5";
			this.numericUpDown5.Size = new System.Drawing.Size(48, 20);
			this.numericUpDown5.TabIndex = 20;
			this.numericUpDown5.ValueChanged += new System.EventHandler(this.numericUpDown5_ValueChanged);
			// 
			// numericUpDown6
			// 
			this.numericUpDown6.Location = new System.Drawing.Point(440, 296);
			this.numericUpDown6.Maximum = new System.Decimal(new int[] {
																		   10000,
																		   0,
																		   0,
																		   0});
			this.numericUpDown6.Name = "numericUpDown6";
			this.numericUpDown6.Size = new System.Drawing.Size(48, 20);
			this.numericUpDown6.TabIndex = 21;
			this.numericUpDown6.ValueChanged += new System.EventHandler(this.numericUpDown6_ValueChanged);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(528, 326);
			this.Controls.Add(this.numericUpDown6);
			this.Controls.Add(this.numericUpDown5);
			this.Controls.Add(this.label10);
			this.Controls.Add(this.label9);
			this.Controls.Add(this.groupBox1);
			this.Controls.Add(this.button8);
			this.Controls.Add(this.button7);
			this.Controls.Add(this.button6);
			this.Controls.Add(this.button5);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.button4);
			this.Controls.Add(this.button3);
			this.Controls.Add(this.checkBox4);
			this.Controls.Add(this.checkBox3);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.checkBox2);
			this.Controls.Add(this.checkBox1);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.button2);
			this.Controls.Add(this.button1);
			this.Controls.Add(this.panel1);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.Name = "Form1";
			this.Text = "Customize AutoScroll Panel";
			this.panel1.ResumeLayout(false);
			this.panel2.ResumeLayout(false);
			this.groupBox1.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.numericUpDown4)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.numericUpDown3)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.numericUpDown5)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.numericUpDown6)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// Point d'entr�e principal de l'application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void panel2_Click(object sender, System.EventArgs e)
		{
			this.panel1.Focus();
		}

		private void checkBox1_CheckedChanged(object sender, System.EventArgs e)
		{
			this.panel1.EnableAutoScrollHorizontal = this.checkBox1.Checked;
		}

		private void checkBox2_CheckedChanged(object sender, System.EventArgs e)
		{
			this.panel1.EnableAutoScrollVertical = this.checkBox2.Checked;
		}

		private void panel1_ScrollHorizontal(object sender, System.Windows.Forms.ScrollEventArgs e)
		{
			this.label2.Text = "horizontal scroll :: type: " + e.Type.ToString();// + " :: pos: " + e.NewValue;
			this.numericUpDown5.Value = e.NewValue;
		}

		private void panel1_ScrollVertical(object sender, System.Windows.Forms.ScrollEventArgs e)
		{
			this.label2.Text = "vertical scroll :: type: " + e.Type.ToString();
			this.numericUpDown6.Value = e.NewValue;
		}

		private void checkBox3_CheckedChanged(object sender, System.EventArgs e)
		{
			this.panel1.VisibleAutoScrollHorizontal = this.checkBox3.Checked;
		}

		private void checkBox4_CheckedChanged(object sender, System.EventArgs e)
		{
			this.panel1.VisibleAutoScrollVertical = this.checkBox4.Checked;
		}

		private void panel1_ScrollMouseWheel(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			this.label4.Text = e.Delta.ToString();
			this.numericUpDown6.Value = this.panel1.AutoScrollVPos;
		}

		private void button3_Click(object sender, System.EventArgs e)
		{
			this.panel1.performScrollHorizontal(ScrollEventType.LargeIncrement);
		}

		private void button4_Click(object sender, System.EventArgs e)
		{
			this.panel1.performScrollHorizontal(ScrollEventType.LargeDecrement);
		}

		private void button1_Click(object sender, System.EventArgs e)
		{
			this.panel1.performScrollVertical(ScrollEventType.LargeDecrement);
		}

		private void button2_Click(object sender, System.EventArgs e)
		{
			this.panel1.performScrollVertical(ScrollEventType.LargeIncrement);
		}

		private void button5_Click(object sender, System.EventArgs e)
		{
			this.panel1.performScrollVertical(ScrollEventType.SmallDecrement);
		}

		private void button6_Click(object sender, System.EventArgs e)
		{
			this.panel1.performScrollVertical(ScrollEventType.SmallIncrement);
		}

		private void button7_Click(object sender, System.EventArgs e)
		{
			this.panel1.performScrollHorizontal(ScrollEventType.SmallIncrement);
		}

		private void button8_Click(object sender, System.EventArgs e)
		{
			this.panel1.performScrollHorizontal(ScrollEventType.SmallDecrement);
		}

		private void numericUpDown1_ValueChanged(object sender, System.EventArgs e)
		{
			this.panel1.AutoScrollHorizontalMinimum = System.Convert.ToInt32( this.numericUpDown1.Value );
		}

		private void numericUpDown2_ValueChanged(object sender, System.EventArgs e)
		{
			this.panel1.AutoScrollHorizontalMaximum = System.Convert.ToInt32( this.numericUpDown2.Value );
		}

		private void numericUpDown3_ValueChanged(object sender, System.EventArgs e)
		{
			this.panel1.AutoScrollVerticalMinimum = System.Convert.ToInt32( this.numericUpDown3.Value );
		}

		private void numericUpDown4_ValueChanged(object sender, System.EventArgs e)
		{
			this.panel1.AutoScrollVerticalMaximum = System.Convert.ToInt32( this.numericUpDown4.Value );
		}

		private void numericUpDown5_ValueChanged(object sender, System.EventArgs e)
		{
			this.panel1.AutoScrollHPos = System.Convert.ToInt32( this.numericUpDown5.Value );
		}

		private void numericUpDown6_ValueChanged(object sender, System.EventArgs e)
		{
			this.panel1.AutoScrollVPos = System.Convert.ToInt32( this.numericUpDown6.Value );
		}

		private void label11_Click(object sender, System.EventArgs e)
		{
			this.panel1.Focus();
		}

	}
}
