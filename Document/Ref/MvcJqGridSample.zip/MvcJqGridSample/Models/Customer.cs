﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MvcJqGridSample.Models
{
    public class Customer
    {
        public int CustomerID { get; set; }

        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string EmailAddress { get; set; }
        public DateTime BirthDate { get; set; }
        public string Phone { get; set; }
        public int CountryID { get; set; }
    }
}