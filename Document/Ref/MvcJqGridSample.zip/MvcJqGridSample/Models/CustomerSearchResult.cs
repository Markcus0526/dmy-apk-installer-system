﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MvcJqGridSample.Models
{
    public class CustomerSearchResult : Customer
    {
        public string CountryName { get; set; }

    }
}