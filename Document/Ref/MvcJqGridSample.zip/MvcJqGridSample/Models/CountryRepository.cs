﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MvcJqGridSample.Models
{
    public class CountryRepository
    {
        List<Country> countries = new List<Country>
        {
            new Country { CountryID = 1, Name = "Brazil"},
            new Country { CountryID = 2, Name = "United Kingdom"},
            new Country { CountryID = 3, Name = "United States of America"},
            new Country { CountryID = 4, Name = "Portugal"},

        };

        public List<Country> Search()
        {
            return countries;
        }
    }
}