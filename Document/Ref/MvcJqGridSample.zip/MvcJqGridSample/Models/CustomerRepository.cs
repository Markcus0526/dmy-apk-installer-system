﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MvcJqGridSample.Models
{
    public class CustomerRepository
    {
        private List<Customer> CustomerData = new List<Customer> 
        {             
            new Customer { CustomerID = 1, EmailAddress = "luis@abc.com", FirstName = "Luis", LastName = "Silverio", BirthDate = new DateTime(2011,1,1), Phone = "123", CountryID = 1 },
            new Customer { CustomerID = 2, EmailAddress = "costa@def.com", FirstName = "Pedro", LastName = "Costa", BirthDate = new DateTime(2012,4,8), Phone = "1233", CountryID = 2 },
            new Customer { CustomerID = 3, EmailAddress = "sousa@def.com", FirstName = "Rui", LastName = "Sousa", BirthDate = new DateTime(2012,4,10), Phone = "1233", CountryID = 3 },
            new Customer { CustomerID = 4, EmailAddress = "michael@abc.com", FirstName = "Michael", LastName = "Costa", BirthDate = new DateTime(2012,5,20), Phone = "217349000", CountryID = 1 },
            new Customer { CustomerID = 5, EmailAddress = "abigail@abc.com", FirstName = "Abigail", LastName = "Smith", BirthDate = new DateTime(2011,1,1), Phone = "123", CountryID = 1 },
            new Customer { CustomerID = 6, EmailAddress = "addison@def.com", FirstName = "Addison", LastName = "Hank", BirthDate = new DateTime(2012,4,8), Phone = "1233", CountryID = 1 },
            new Customer { CustomerID = 7, EmailAddress = "johnson@def.com", FirstName = "Johnson", LastName = "Streep", BirthDate = new DateTime(2012,4,10), Phone = "1233", CountryID = 2 },
            new Customer { CustomerID = 8, EmailAddress = "williams@abc.com", FirstName = "Williams", LastName = "Stone", BirthDate = new DateTime(2011,1,1), Phone = "123", CountryID = 2 },
            new Customer { CustomerID = 9, EmailAddress = "james@def.com", FirstName = "James", LastName = "Brown", BirthDate = new DateTime(2012,4,8), Phone = "1233", CountryID = 2 },
            new Customer { CustomerID = 10, EmailAddress = "davis@def.com", FirstName = "Davis", LastName = "Campbell", BirthDate = new DateTime(2012,4,10), Phone = "1233", CountryID = 1 },
            new Customer { CustomerID = 11, EmailAddress = "david@abc.com", FirstName = "David", LastName = "Scott", BirthDate = new DateTime(2011,1,1), Phone = "123", CountryID = 3 },
            new Customer { CustomerID = 12, EmailAddress = "richard@def.com", FirstName = "Richard", LastName = "Lewis", BirthDate = new DateTime(2012,4,8), Phone = "1233", CountryID = 3 },
            new Customer { CustomerID = 13, EmailAddress = "thomas@def.com", FirstName = "Thomas", LastName = "Rodriguez", BirthDate = new DateTime(2012,4,10), Phone = "1233", CountryID = 2 },
        };

        public List<CustomerSearchResult> Search(CustomerSeachFilter filter, string sortColumn, string sortOrder, int pageSize, int pageIndex, out int totalRecords)
        {
            var countries = new CountryRepository().Search();
            var q = from c in CustomerData
                    join country in countries on c.CountryID equals country.CountryID 
                    select new CustomerSearchResult 
                    {
                        CustomerID = c.CustomerID,
                        EmailAddress = c.EmailAddress,
                        FirstName = c.FirstName,
                        LastName = c.LastName,
                        BirthDate = c.BirthDate,
                        Phone = c.Phone,
                        CountryID = c.CountryID,
                        CountryName = country.Name
                    };

            if (!string.IsNullOrEmpty(filter.FirstName))
            {
                q = q.Where(c => c.FirstName.ToLower().Contains(filter.FirstName.ToLower()));
            }
            if (!string.IsNullOrEmpty(filter.LastName))
            {
                q = q.Where(c => c.LastName.ToLower().Contains(filter.LastName.ToLower()));
            }
            if (!string.IsNullOrEmpty(filter.Phone))
            {
                q = q.Where(c => c.Phone.ToLower().Contains(filter.Phone.ToLower()));
            }
            if (filter.BirthDate !=  DateTime.MinValue)
            {
                q = q.Where(c => c.BirthDate.Equals(filter.BirthDate));
            }
            if (!string.IsNullOrEmpty(filter.CountryName))
            {
                q = q.Where(c => c.CountryName.ToLower().Contains(filter.CountryName.ToLower()));
            }

            switch (sortColumn)
            {
                case "CustomerId":
                    q = (sortOrder == "desc") ? q.OrderByDescending(c => c.CustomerID) : q.OrderBy(c => c.CustomerID);
                    break;
                case "FirstName":
                    q = (sortOrder == "desc") ? q.OrderByDescending(c => c.FirstName) : q.OrderBy(c => c.FirstName);
                    break;
                case "LastName":
                    q = (sortOrder == "desc") ? q.OrderByDescending(c => c.LastName) : q.OrderBy(c => c.LastName);
                    break;
                case "BirthDate":
                    q = (sortOrder == "desc") ? q.OrderByDescending(c => c.BirthDate) : q.OrderBy(c => c.BirthDate);
                    break;
                case "Email Address":
                    q = (sortOrder == "desc") ? q.OrderByDescending(c => c.EmailAddress) : q.OrderBy(c => c.EmailAddress);
                    break;
                case "Birth Date":
                    q = (sortOrder == "desc") ? q.OrderByDescending(c => c.BirthDate) : q.OrderBy(c => c.BirthDate);
                    break;
                case "Telephone":
                    q = (sortOrder == "desc") ? q.OrderByDescending(c => c.Phone) : q.OrderBy(c => c.Phone);
                    break;
                case "Country":
                    q = (sortOrder == "desc") ? q.OrderByDescending(c => c.CountryName) : q.OrderBy(c => c.CountryName);
                    break;
                default:
                    break;
            }
            totalRecords = q.Count();
            return q.Skip((pageIndex - 1) * pageSize).Take(pageSize).ToList();
        }

        internal Customer Get(int? id)
        {
            if (id.GetValueOrDefault(0) > 0)
            {
                return CustomerData[id.Value];
            }
            else
            {
                return null;
            }
        }
    }
}