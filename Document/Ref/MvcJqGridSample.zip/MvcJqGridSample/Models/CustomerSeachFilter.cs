﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MvcJqGridSample.Models
{
    public class CustomerSeachFilter
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string CountryName { get; set; }
        public string Phone { get; set; }
        public DateTime BirthDate { get; set; }
    }
}