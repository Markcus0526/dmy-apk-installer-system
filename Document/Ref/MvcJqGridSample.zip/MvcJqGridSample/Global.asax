﻿<%@ Application Codebehind="Global.asax.cs" Inherits="MvcJqGridSample.MvcApplication" Language="C#" %>
