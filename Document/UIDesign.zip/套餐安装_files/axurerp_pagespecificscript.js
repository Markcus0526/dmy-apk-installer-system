﻿for(var i = 0; i < 126; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u59'] = 'top';gv_vAlignTable['u52'] = 'center';gv_vAlignTable['u25'] = 'center';gv_vAlignTable['u113'] = 'center';document.getElementById('u46_img').tabIndex = 0;

u46.style.cursor = 'pointer';
$axure.eventManager.click('u46', function(e) {

if (true) {

	SetPanelState('u43', 'pd1u43','none','',500,'none','',500);

}
});
gv_vAlignTable['u76'] = 'center';document.getElementById('u66_img').tabIndex = 0;

u66.style.cursor = 'pointer';
$axure.eventManager.click('u66', function(e) {

if (true) {

	SetPanelState('u43', 'pd1u43','none','',500,'none','',500);

}
});
gv_vAlignTable['u27'] = 'center';gv_vAlignTable['u93'] = 'center';gv_vAlignTable['u102'] = 'center';
u23.style.cursor = 'pointer';
$axure.eventManager.click('u23', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('手机管理.html');

}
});
document.getElementById('u53_img').tabIndex = 0;

u53.style.cursor = 'pointer';
$axure.eventManager.click('u53', function(e) {

if (true) {

	SetPanelState('u43', 'pd0u43','none','',500,'none','',500);

	BringToFront("u43");

}
});
gv_vAlignTable['u42'] = 'center';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u38'] = 'top';gv_vAlignTable['u7'] = 'center';gv_vAlignTable['u123'] = 'top';gv_vAlignTable['u97'] = 'center';gv_vAlignTable['u115'] = 'center';gv_vAlignTable['u104'] = 'center';gv_vAlignTable['u106'] = 'center';gv_vAlignTable['u67'] = 'center';gv_vAlignTable['u30'] = 'top';document.getElementById('u60_img').tabIndex = 0;

u60.style.cursor = 'pointer';
$axure.eventManager.click('u60', function(e) {

if (true) {

	SetPanelState('u43', 'pd1u43','none','',500,'none','',500);

}
});
gv_vAlignTable['u89'] = 'center';gv_vAlignTable['u122'] = 'top';u111.tabIndex = 0;

u111.style.cursor = 'pointer';
$axure.eventManager.click('u111', function(e) {

if (true) {

	SetPanelState('u43', 'pd2u43','none','',500,'none','',500);

	BringToFront("u43");

}
});
gv_vAlignTable['u111'] = 'top';gv_vAlignTable['u117'] = 'center';gv_vAlignTable['u19'] = 'top';gv_vAlignTable['u13'] = 'top';document.getElementById('u79_img').tabIndex = 0;

u79.style.cursor = 'pointer';
$axure.eventManager.click('u79', function(e) {

if (true) {

	SetPanelState('u43', 'pd0u43','none','',500,'none','',500);

	BringToFront("u43");

}
});
u81.tabIndex = 0;

u81.style.cursor = 'pointer';
$axure.eventManager.click('u81', function(e) {

if (true) {

	SetPanelState('u43', 'pd0u43','none','',500,'none','',500);

	BringToFront("u43");

}
});
gv_vAlignTable['u81'] = 'top';document.getElementById('u56_img').tabIndex = 0;

u56.style.cursor = 'pointer';
$axure.eventManager.click('u56', function(e) {

if (true) {

	SetPanelState('u43', 'pd0u43','none','',500,'none','',500);

	BringToFront("u43");

}
});
u55.tabIndex = 0;

u55.style.cursor = 'pointer';
$axure.eventManager.click('u55', function(e) {

if (true) {

	SetPanelState('u43', 'pd0u43','none','',500,'none','',500);

	BringToFront("u43");

}
});
gv_vAlignTable['u55'] = 'top';u11.tabIndex = 0;

u11.style.cursor = 'pointer';
$axure.eventManager.click('u11', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('数据统计.html');

}
});
gv_vAlignTable['u11'] = 'top';document.getElementById('u41_img').tabIndex = 0;

u41.style.cursor = 'pointer';
$axure.eventManager.click('u41', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('设置.html');

}
});
gv_vAlignTable['u17'] = 'center';gv_vAlignTable['u45'] = 'center';document.getElementById('u118_img').tabIndex = 0;

u118.style.cursor = 'pointer';
$axure.eventManager.click('u118', function(e) {

if (true) {

	SetPanelState('u43', 'pd1u43','none','',500,'none','',500);

	BringToFront("u43");

}
});
gv_vAlignTable['u87'] = 'center';gv_vAlignTable['u83'] = 'center';gv_vAlignTable['u57'] = 'center';gv_vAlignTable['u22'] = 'center';document.getElementById('u98_img').tabIndex = 0;

u98.style.cursor = 'pointer';
$axure.eventManager.click('u98', function(e) {

if (true) {

	SetPanelState('u43', 'pd2u43','none','',500,'none','',500);

	BringToFront("u43");

}
});
gv_vAlignTable['u84'] = 'top';gv_vAlignTable['u3'] = 'center';gv_vAlignTable['u109'] = 'center';document.getElementById('u90_img').tabIndex = 0;

u90.style.cursor = 'pointer';
$axure.eventManager.click('u90', function(e) {

if (true) {

	SetPanelState('u43', 'pd2u43','none','',500,'none','',500);

	BringToFront("u43");

}
});
gv_vAlignTable['u20'] = 'top';gv_vAlignTable['u50'] = 'center';gv_vAlignTable['u71'] = 'center';gv_vAlignTable['u54'] = 'center';gv_vAlignTable['u69'] = 'center';document.getElementById('u114_img').tabIndex = 0;

u114.style.cursor = 'pointer';
$axure.eventManager.click('u114', function(e) {

if (true) {

	SetPanelState('u43', 'pd2u43','none','',500,'none','',500);

	BringToFront("u43");

}
});
document.getElementById('u96_img').tabIndex = 0;

u96.style.cursor = 'pointer';
$axure.eventManager.click('u96', function(e) {

if (true) {

	SetPanelState('u43', 'pd1u43','none','',500,'none','',500);

	BringToFront("u43");

}
});
gv_vAlignTable['u61'] = 'center';gv_vAlignTable['u8'] = 'top';gv_vAlignTable['u35'] = 'center';gv_vAlignTable['u65'] = 'center';u110.tabIndex = 0;

u110.style.cursor = 'pointer';
$axure.eventManager.click('u110', function(e) {

if (true) {

	SetPanelState('u43', 'pd1u43','none','',500,'none','',500);

	BringToFront("u43");

}
});
gv_vAlignTable['u110'] = 'top';document.getElementById('u116_img').tabIndex = 0;

u116.style.cursor = 'pointer';
$axure.eventManager.click('u116', function(e) {

if (true) {

	SetPanelState('u43', 'pd2u43','none','',500,'none','',500);

	BringToFront("u43");

}
});
gv_vAlignTable['u5'] = 'center';gv_vAlignTable['u95'] = 'center';document.getElementById('u82_img').tabIndex = 0;

u82.style.cursor = 'pointer';
$axure.eventManager.click('u82', function(e) {

if (true) {

	SetPanelState('u43', 'pd0u43','none','',500,'none','',500);

	BringToFront("u43");

}
});
u85.tabIndex = 0;

u85.style.cursor = 'pointer';
$axure.eventManager.click('u85', function(e) {

if (true) {

	SetPanelState('u43', 'pd2u43','none','',500,'none','',500);

	BringToFront("u43");

}
});
gv_vAlignTable['u85'] = 'top';document.getElementById('u9_img').tabIndex = 0;

u9.style.cursor = 'pointer';
$axure.eventManager.click('u9', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('数据统计.html');

}
});
document.getElementById('u112_img').tabIndex = 0;

u112.style.cursor = 'pointer';
$axure.eventManager.click('u112', function(e) {

if (true) {

	SetPanelState('u43', 'pd1u43','none','',500,'none','',500);

	BringToFront("u43");

}
});
document.getElementById('u72_img').tabIndex = 0;

u72.style.cursor = 'pointer';
$axure.eventManager.click('u72', function(e) {

if (true) {

	SetPanelState('u43', 'pd2u43','none','',500,'none','',500);

	BringToFront("u43");

}
});
gv_vAlignTable['u107'] = 'top';gv_vAlignTable['u63'] = 'center';gv_vAlignTable['u18'] = 'top';gv_vAlignTable['u37'] = 'center';gv_vAlignTable['u121'] = 'center';gv_vAlignTable['u78'] = 'center';gv_vAlignTable['u47'] = 'center';gv_vAlignTable['u80'] = 'center';u58.tabIndex = 0;

u58.style.cursor = 'pointer';
$axure.eventManager.click('u58', function(e) {

if (true) {

	SetPanelState('u43', 'pd1u43','none','',500,'none','',500);

}
});
gv_vAlignTable['u58'] = 'top';document.getElementById('u88_img').tabIndex = 0;

u88.style.cursor = 'pointer';
$axure.eventManager.click('u88', function(e) {

if (true) {

	SetPanelState('u43', 'pd2u43','none','',500,'none','',500);

	BringToFront("u43");

}
});
gv_vAlignTable['u10'] = 'center';gv_vAlignTable['u40'] = 'center';document.getElementById('u70_img').tabIndex = 0;

u70.style.cursor = 'pointer';
$axure.eventManager.click('u70', function(e) {

if (true) {

	SetPanelState('u43', 'pd0u43','none','',500,'none','',500);

	BringToFront("u43");

}
});
gv_vAlignTable['u99'] = 'center';gv_vAlignTable['u73'] = 'center';document.getElementById('u44_img').tabIndex = 0;

u44.style.cursor = 'pointer';
$axure.eventManager.click('u44', function(e) {

if (true) {

	SetPanelState('u43', 'pd0u43','none','',500,'none','',500);

	BringToFront("u43");

}
});
gv_vAlignTable['u29'] = 'center';gv_vAlignTable['u119'] = 'center';document.getElementById('u4_img').tabIndex = 0;

u4.style.cursor = 'pointer';
$axure.eventManager.click('u4', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('数据统计.html');

}
});
gv_vAlignTable['u14'] = 'top';gv_vAlignTable['u91'] = 'center';