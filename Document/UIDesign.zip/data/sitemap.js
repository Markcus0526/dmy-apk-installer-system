﻿var sitemap = 

(function() {
    var _ = function() { var r={},a=arguments; for(var i=0; i<a.length; i+=2) r[a[i]]=a[i+1]; return r; }
    var _creator = function() { return _(b,[_(c,d,e,f,g,h),_(c,i,e,f,g,j),_(c,k,e,f,g,l),_(c,m,e,f,g,n),_(c,o,e,f,g,p)]);}; 
var b="rootNodes",c="pageName",d="登陆",e="type",f="Wireframe",g="url",h="登陆.html",i="套餐安装",j="套餐安装.html",k="数据统计",l="数据统计.html",m="手机管理",n="手机管理.html",o="设置",p="设置.html";
return _creator();
})();
